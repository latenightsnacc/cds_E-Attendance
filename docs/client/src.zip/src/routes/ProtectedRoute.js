import React from 'react';
import { Route, Navigate } from "react-router-dom";


const ProtectedRoute = ({component: Component, path, isAuth, ...rest}) => {
    

    return(
        <Route
            path={path}
            render={ (props) => {
                
                 if (isAuth) {
                     return <Component />
                 } else {
                     return(
                         <Navigate to={ {pathname: "/", state:{from: props.location}}} />
                     )
                 }
            }}
            {...rest}
        />
    )
}

export default ProtectedRoute;