const SecretaryGeneral = () => {
    return(
        <div>
            <h1>Good morning, Secretary General</h1>
        </div>
    )
}
export default SecretaryGeneral;