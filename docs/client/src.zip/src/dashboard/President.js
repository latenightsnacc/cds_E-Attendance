const President = () => {
    return(
        <div>
            <h1>Good morning, President</h1>
        </div>
    )
}
export default President;