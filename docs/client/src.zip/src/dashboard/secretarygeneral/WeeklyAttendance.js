const WeeklyAttendance = () => {
    return(
        <div>
            <h1>Weekly Attendance</h1>
        </div>
    )
}
export default WeeklyAttendance;