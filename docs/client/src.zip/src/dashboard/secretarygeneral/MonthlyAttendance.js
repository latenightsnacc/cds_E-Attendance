const MonthlyAttendance = () => {
    return(
        <div>
            <h1>Monthly Attendance</h1>
        </div>
    )
}
export default MonthlyAttendance;