const Note = () => {
    return(
        <div>
            <h1>Note</h1>
        </div>
    )
}
export default Note;