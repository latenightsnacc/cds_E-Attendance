const NewAttendance = () => {
    return(
        <div>
            <h1>New Attendance</h1>
        </div>
    )
}
export default NewAttendance;