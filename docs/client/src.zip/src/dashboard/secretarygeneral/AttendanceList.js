const AttendanceList = () => {
    return(
        <div>
            <h1>Attendance List</h1>
        </div>
    )
}
export default AttendanceList;