const NotesList = () => {
    return(
        <div>
            <h1>New Attendance</h1>
        </div>
    )
}
export default NotesList;