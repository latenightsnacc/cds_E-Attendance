const NewNote = () => {
    return(
        <div>
            <h1>New Note</h1>
        </div>
    )
}
export default NewNote;