const Coordinator = () => {
    return(
        <div>
            <h1>Good morning, Coordinator</h1>
        </div>
    )
}
export default Coordinator;