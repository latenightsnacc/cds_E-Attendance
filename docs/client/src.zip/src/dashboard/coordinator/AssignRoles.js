const AssignRoles = () => {
    return(
        <div>
            <h1>Member Roles & Privileges</h1>
        </div>
    )
}

export default AssignRoles;