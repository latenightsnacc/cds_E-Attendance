const MonthlyDue = () => {
    return(
        <div>
            <h1>Monthly Due</h1>
        </div>
    )
}
export default MonthlyDue;