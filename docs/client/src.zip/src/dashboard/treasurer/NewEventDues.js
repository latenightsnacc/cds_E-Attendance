const NewEventDues = () => {
    return(
        <div>
            <h1>New Event Due</h1>
        </div>
    )
}
export default NewEventDues;