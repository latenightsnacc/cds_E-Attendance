const MonthlyDuesList = () => {
    return(
        <div>
            <h1>Monthly Dues List</h1>
        </div>
    )
}
export default MonthlyDuesList;