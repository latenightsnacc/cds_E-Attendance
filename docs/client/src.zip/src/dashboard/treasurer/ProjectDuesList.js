const ProjectDuesList = () => {
    return(
        <div>
            <h1>Project Dues List</h1>
        </div>
    )
}
export default ProjectDuesList;