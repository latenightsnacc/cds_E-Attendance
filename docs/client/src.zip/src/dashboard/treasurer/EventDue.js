const EventDue = () => {
    return(
        <div>
            <h1>Event Due</h1>
        </div>
    )
}
export default EventDue;