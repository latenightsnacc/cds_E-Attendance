const NewMonthlyDues = () => {
    return(
        <div>
            <h1>New Monthly Due</h1>
        </div>
    )
}
export default NewMonthlyDues;