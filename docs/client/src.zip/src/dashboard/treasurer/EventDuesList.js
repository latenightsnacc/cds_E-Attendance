const EventDuesList = () => {
    return(
        <div>
            <h1>Event Dues List</h1>
        </div>
    )
}
export default EventDuesList;