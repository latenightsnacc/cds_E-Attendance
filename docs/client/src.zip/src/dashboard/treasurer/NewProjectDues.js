const NewProjectDues = () => {
    return(
        <div>
            <h1>New Project Due</h1>
        </div>
    )
}
export default NewProjectDues;