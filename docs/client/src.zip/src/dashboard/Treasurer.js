const Treasurer = () => {
    return(
        <div>
            <h1>Good morning, Treasurer</h1>
        </div>
    )
}
export default Treasurer;