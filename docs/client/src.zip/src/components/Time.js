const Time = () => {
    return(
        <div></div>
    )
}

export default Time;